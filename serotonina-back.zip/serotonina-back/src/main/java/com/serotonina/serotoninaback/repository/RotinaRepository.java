package com.serotonina.serotoninaback.repository;

import org.springframework.data.repository.CrudRepository;

import com.serotonina.serotoninaback.model.Rotina;

public interface RotinaRepository extends CrudRepository<Rotina, Long>{
    
}
